# JARVIS for Android

A native Android starter app with a dark blue JARVIS-inspired interface, speech-to-text input, British English text-to-speech, chat history for the current session, and OpenAI API connectivity.

## What it does
- Voice input using Android's speech recognition service (tap SPEAK).
- Spoken replies using Android Text-to-Speech (English UK voice, if installed on the phone).
- AI conversation through the OpenAI Chat Completions API (`gpt-4o-mini`).
- API key entry in Settings, stored with AndroidX EncryptedSharedPreferences.
- No always-on microphone. Android background microphone access is restricted; this version listens only after you tap SPEAK.

## Important
This is the Android Studio source project, not a prebuilt APK. This workspace does not have the Android SDK/Gradle build environment needed to compile and sign an installable APK.

You need:
1. Android Studio on a Windows/Mac/Linux computer.
2. Open this folder as a project.
3. Let Android Studio sync Gradle and install any requested SDK components.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the resulting APK on your Android phone.
6. Create an OpenAI API key in your OpenAI developer account and add it in JARVIS Settings.

API usage is billed separately by the API provider; a ChatGPT subscription does not include API credit. Treat the key like a password. This app is intended as a personal prototype; for a public release, route requests through a secure backend rather than shipping API keys in a mobile client.

## Build settings
- Package: `com.example.jarvis`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- App name: JARVIS

## Current limitations
- No wake-word activation while the app is closed.
- No computer or smart-home control yet.
- Conversation history is held in memory for the current app session.
- Voice recognition quality and available UK voices depend on Android services installed on the phone.
